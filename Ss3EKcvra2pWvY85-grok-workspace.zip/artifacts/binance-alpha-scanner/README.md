# Binance Alpha New Coin Scanner & Trading Dashboard

Real-time web dashboard that monitors **Binance Alpha** for newly launching tokens, displays them with live data, and supports one-click buying via your Binance API keys.

## Features

- **New Coin Detection**: Polls the official Binance Alpha Token List every ~1.5s and detects new listings instantly.
- **Live WebSocket Data**: Connects to `wss://nbstream.binance.com/w3w/wsa/stream` (`came@allTokens@ticker24` + per-coin streams).
- **Dashboard Columns** (exact match to your design):
  - CHAIN | COIN (clickable → Binance chart) | AGE | SIZE | ENTRY ZONE | CURRENT PRICE | GAIN | 24H CHANGE | TRAILING SL | TP PROGRESS | SIGNALS | TRADE | CLOSE
- **One-click Buy**: Enter your Binance API Key + Secret (stored only in browser localStorage).
- **Position Tracking**: Basic entry price, gain calculation, trailing stop placeholder, TP progress.
- **Dark modern UI** matching the attached screenshot style.
- Fully free public endpoints (no paid API needed for scanning).

## Tech Stack

- **Backend**: Node.js + Express + `ws` + Socket.io
- **Frontend**: React (Vite) + Tailwind CSS + Socket.io-client
- **Data**: Official Binance Alpha REST + WebSocket

## Quick Start

### 1. Backend

```bash
cd backend
npm install
npm run dev
```

Backend runs on `http://localhost:3001`

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on `http://localhost:5173`

Open the browser → dashboard will connect automatically via Socket.io.

## Configuration

- In the UI Settings panel you can paste your Binance API Key & Secret.
- They are stored in `localStorage` only (never sent to any third party).
- One-click buy uses the official Binance Spot REST API to place a market order on the `ALPHA_xxxUSDT` pair.

## Important Notes

- Alpha tokens use symbols like `ALPHA_175USDT`.
- Chart link example: `https://www.binance.com/en/trade/ALPHA_175USDT`
- Always start with small size and testnet if possible.
- This is a monitoring + convenience tool. Trading involves high risk (new coins are extremely volatile).

## Project Structure

```
binance-alpha-scanner/
├── backend/
│   ├── src/
│   │   ├── index.js              # Main server + Socket.io
│   │   ├── services/
│   │   │   ├── alphaPoller.js    # Token List polling + new coin detection
│   │   │   ├── alphaWs.js        # Binance Alpha WebSocket client
│   │   │   └── positionTracker.js
│   │   ├── routes/
│   │   └── utils/
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── components/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Settings.jsx
│   │   │   └── TokenRow.jsx
│   │   └── ...
│   └── package.json
└── README.md
```

## License

MIT – use at your own risk.
