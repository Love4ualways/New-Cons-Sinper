import fetch from 'node-fetch';

const TOKEN_LIST_URL = 'https://www.binance.com/bapi/defi/v1/public/wallet-direct/buw/wallet/cex/alpha/all/token/list';
const POLL_INTERVAL_MS = 1500;

export class AlphaPoller {
  constructor({ onNewToken, onTokenListUpdate }) {
    this.knownTokens = new Map(); // symbol -> token data
    this.onNewToken = onNewToken;
    this.onTokenListUpdate = onTokenListUpdate;
    this.running = false;
    this.timer = null;
    this.firstRun = true;
  }

  async fetchTokenList() {
    try {
      const res = await fetch(TOKEN_LIST_URL, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; AlphaScanner/1.0)',
          'Accept': 'application/json'
        },
        timeout: 8000
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      if (!json.success || !Array.isArray(json.data)) {
        throw new Error('Invalid response structure');
      }
      return json.data;
    } catch (err) {
      console.error('[AlphaPoller] Fetch error:', err.message);
      return null;
    }
  }

  processTokens(tokens) {
    const now = Date.now();
    const currentSymbols = new Set();

    for (const t of tokens) {
      const symbol = (t.symbol || '').toUpperCase();
      if (!symbol) continue;

      currentSymbols.add(symbol);

      const existing = this.knownTokens.get(symbol);
      if (!existing) {
        // New token
        const tokenData = {
          ...t,
          symbol,
          detectedAt: now,
          firstSeen: now,
          alphaId: t.tokenId || t.alphaId || null,
          chainName: t.chainName || 'Unknown',
          chainId: t.chainId || '',
          contractAddress: t.contractAddress || '',
          name: t.name || symbol,
          iconUrl: t.iconUrl || null,
          // Live fields (will be updated by WS)
          price: null,
          priceChange24h: null,
          volume24h: null,
          liquidity: null,
          marketCap: null,
          fdv: null,
          holders: null,
          // Trading state
          entryPrice: null,
          size: null,          // position size in quote
          gain: null,
          trailingSL: null,
          tpProgress: 0,
          signals: [],
          status: 'new'        // new | watching | open | closed
        };

        this.knownTokens.set(symbol, tokenData);

        if (!this.firstRun) {
          console.log(`[NEW] ${symbol} on ${tokenData.chainName}`);
          this.onNewToken?.(tokenData);
        }
      } else {
        // Update static fields if needed
        existing.chainName = t.chainName || existing.chainName;
        existing.contractAddress = t.contractAddress || existing.contractAddress;
        existing.iconUrl = t.iconUrl || existing.iconUrl;
      }
    }

    // Optional: mark removed tokens (rarely needed)
    this.firstRun = false;
    this.onTokenListUpdate?.(Array.from(this.knownTokens.values()));
  }

  async tick() {
    const tokens = await this.fetchTokenList();
    if (tokens) {
      this.processTokens(tokens);
    }
  }

  start() {
    if (this.running) return;
    this.running = true;
    console.log('[AlphaPoller] Started (interval', POLL_INTERVAL_MS, 'ms)');
    this.tick();
    this.timer = setInterval(() => this.tick(), POLL_INTERVAL_MS);
  }

  stop() {
    this.running = false;
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  getAllTokens() {
    return Array.from(this.knownTokens.values());
  }

  getToken(symbol) {
    return this.knownTokens.get(symbol.toUpperCase());
  }

  updateLiveData(symbol, live) {
    const t = this.knownTokens.get(symbol.toUpperCase());
    if (!t) return null;
    Object.assign(t, live);
    // Recalculate gain if we have entry
    if (t.entryPrice && t.price) {
      t.gain = ((t.price - t.entryPrice) / t.entryPrice) * 100;
    }
    return t;
  }
}
