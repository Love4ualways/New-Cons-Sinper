import WebSocket from 'ws';

const ALPHA_WS_URL = 'wss://nbstream.binance.com/w3w/wsa/stream';

export class AlphaWebSocket {
  constructor({ onTickerUpdate, onError }) {
    this.ws = null;
    this.onTickerUpdate = onTickerUpdate;
    this.onError = onError;
    this.subscribed = new Set();
    this.reconnectAttempts = 0;
    this.maxReconnect = 20;
    this.pingInterval = null;
  }

  connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    console.log('[AlphaWS] Connecting to', ALPHA_WS_URL);
    this.ws = new WebSocket(ALPHA_WS_URL);

    this.ws.on('open', () => {
      console.log('[AlphaWS] Connected');
      this.reconnectAttempts = 0;
      // Subscribe to all-tokens 24h ticker stream
      this.subscribe(['came@allTokens@ticker24']);
      // Also all mini tickers for extra coverage
      this.subscribe(['!miniTicker@arr']);

      // Keep alive
      this.pingInterval = setInterval(() => {
        if (this.ws?.readyState === WebSocket.OPEN) {
          this.ws.ping();
        }
      }, 20000);
    });

    this.ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        this.handleMessage(msg);
      } catch (e) {
        // ignore non-json
      }
    });

    this.ws.on('close', () => {
      console.log('[AlphaWS] Closed');
      clearInterval(this.pingInterval);
      this.scheduleReconnect();
    });

    this.ws.on('error', (err) => {
      console.error('[AlphaWS] Error:', err.message);
      this.onError?.(err);
    });
  }

  scheduleReconnect() {
    if (this.reconnectAttempts >= this.maxReconnect) {
      console.error('[AlphaWS] Max reconnect attempts reached');
      return;
    }
    const delay = Math.min(1000 * Math.pow(1.5, this.reconnectAttempts), 30000);
    this.reconnectAttempts++;
    console.log(`[AlphaWS] Reconnecting in ${Math.round(delay)}ms (attempt ${this.reconnectAttempts})`);
    setTimeout(() => this.connect(), delay);
  }

  subscribe(streams) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    const toSub = streams.filter(s => !this.subscribed.has(s));
    if (toSub.length === 0) return;

    const payload = {
      method: 'SUBSCRIBE',
      params: toSub,
      id: Date.now()
    };
    this.ws.send(JSON.stringify(payload));
    toSub.forEach(s => this.subscribed.add(s));
    console.log('[AlphaWS] Subscribed:', toSub.join(', '));
  }

  subscribeSymbol(symbol) {
    // symbol format expected by stream: alpha_116usdt (lowercase)
    const streamSymbol = symbol.toLowerCase().replace('usdt', 'usdt');
    // If it is already ALPHA_xxxUSDT we keep it
    const streams = [
      `${streamSymbol}@miniTicker`,
      `${streamSymbol}@ticker`
    ];
    this.subscribe(streams);
  }

  handleMessage(msg) {
    // Combined stream format or direct
    const data = msg.data || msg;
    const stream = msg.stream || '';

    // All tokens 24h ticker
    if (stream === 'came@allTokens@ticker24' || data.e === 'tickerList') {
      const list = data.d || [];
      for (const item of list) {
        // ca = contract@chainId
        // We need to map back to symbol. The stream doesn't always give symbol directly.
        // For now we emit raw and let the poller merge by other means if needed.
        // Many implementations use the token list as source of truth for symbol mapping.
        this.onTickerUpdate?.({
          type: 'allTokens24h',
          raw: item
        });
      }
      return;
    }

    // Mini ticker (single or array)
    if (data.e === '24hrMiniTicker') {
      const symbol = (data.s || '').toUpperCase();
      if (!symbol) return;
      this.onTickerUpdate?.({
        type: 'miniTicker',
        symbol,
        price: parseFloat(data.c),
        open: parseFloat(data.o),
        high: parseFloat(data.h),
        low: parseFloat(data.l),
        volume: parseFloat(data.v),
        quoteVolume: parseFloat(data.q)
      });
      return;
    }

    // Full ticker
    if (data.e === '24hrTicker') {
      const symbol = (data.s || '').toUpperCase();
      if (!symbol) return;
      this.onTickerUpdate?.({
        type: 'ticker',
        symbol,
        price: parseFloat(data.c),
        priceChange: parseFloat(data.p),
        priceChangePercent: parseFloat(data.P),
        volume: parseFloat(data.v),
        quoteVolume: parseFloat(data.q),
        high: parseFloat(data.h),
        low: parseFloat(data.l)
      });
    }
  }

  disconnect() {
    clearInterval(this.pingInterval);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
  }
}
