import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import { AlphaPoller } from './services/alphaPoller.js';
import { AlphaWebSocket } from './services/alphaWs.js';
import tradeRouter from './routes/trade.js';

const PORT = process.env.PORT || 3001;

const app = express();
app.use(cors());
app.use(express.json());
app.use('/api/trade', tradeRouter);

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

// ---- Core services ----
const poller = new AlphaPoller({
  onNewToken: (token) => {
    console.log('Broadcasting new token:', token.symbol);
    io.emit('new_token', token);
    // Also ask WS to subscribe to its ticker if possible
    if (token.alphaId || token.tokenId) {
      // Construct possible trading symbol
      // Alpha trading symbols are usually ALPHA_<id>USDT
      const tradingSymbol = `ALPHA_${token.tokenId || token.alphaId}USDT`;
      alphaWs.subscribeSymbol(tradingSymbol);
    }
  },
  onTokenListUpdate: (all) => {
    // Throttled full snapshot for new clients
  }
});

const alphaWs = new AlphaWebSocket({
  onTickerUpdate: (update) => {
    if (update.type === 'miniTicker' || update.type === 'ticker') {
      const live = {
        price: update.price,
        priceChange24h: update.priceChangePercent ?? null,
        volume24h: update.quoteVolume || update.volume,
        high: update.high,
        low: update.low
      };
      const updated = poller.updateLiveData(update.symbol, live);
      if (updated) {
        io.emit('token_update', updated);
      }
    }
    // allTokens24h is harder to map without contract→symbol lookup.
    // We rely mainly on the Token List + miniTicker for now.
  },
  onError: (err) => {
    io.emit('ws_error', { message: err.message });
  }
});

// ---- Socket.io ----
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  // Send current snapshot
  const tokens = poller.getAllTokens()
    .sort((a, b) => (b.detectedAt || 0) - (a.detectedAt || 0));
  socket.emit('snapshot', tokens);

  // Client can request a buy (we just forward the request – actual signing happens client-side or via secure proxy)
  socket.on('place_order', async (payload) => {
    // For security we do NOT store API keys on server by default.
    // Client signs or we implement a temporary proxy if user wants.
    // Here we just acknowledge and let frontend call Binance directly with their key.
    socket.emit('order_ack', { status: 'received', payload });
  });

  socket.on('update_position', ({ symbol, entryPrice, size, trailingSL }) => {
    const t = poller.getToken(symbol);
    if (t) {
      t.entryPrice = entryPrice;
      t.size = size;
      t.trailingSL = trailingSL;
      t.status = 'open';
      if (t.price && entryPrice) {
        t.gain = ((t.price - entryPrice) / entryPrice) * 100;
      }
      io.emit('token_update', t);
    }
  });

  socket.on('close_position', ({ symbol }) => {
    const t = poller.getToken(symbol);
    if (t) {
      t.status = 'closed';
      t.entryPrice = null;
      t.size = null;
      t.gain = null;
      io.emit('token_update', t);
    }
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// Health


app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    tokensTracked: poller.getAllTokens().length,
    uptime: process.uptime()
  });
});

app.get('/tokens', (req, res) => {
  res.json(poller.getAllTokens());
});

// Start everything
server.listen(PORT, () => {
  console.log(`Backend listening on http://localhost:${PORT}`);
  poller.start();
  alphaWs.connect();
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('Shutting down...');
  poller.stop();
  alphaWs.disconnect();
  process.exit(0);
});
