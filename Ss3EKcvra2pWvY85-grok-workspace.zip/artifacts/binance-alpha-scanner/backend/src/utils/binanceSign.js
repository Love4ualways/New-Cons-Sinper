/**
 * Simple HMAC-SHA256 signer for Binance Spot API.
 * Use only on a secure backend in production.
 */
import crypto from 'crypto';

export function signQuery(queryString, secret) {
  return crypto
    .createHmac('sha256', secret)
    .update(queryString)
    .digest('hex');
}

export function buildSignedQuery(params, secret) {
  const qs = new URLSearchParams(params).toString();
  const signature = signQuery(qs, secret);
  return `${qs}&signature=${signature}`;
}
