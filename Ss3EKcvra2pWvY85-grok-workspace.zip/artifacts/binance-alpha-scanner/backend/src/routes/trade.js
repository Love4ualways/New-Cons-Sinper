import express from 'express';
import { buildSignedQuery } from '../utils/binanceSign.js';

const router = express.Router();

/**
 * POST /api/trade/market-buy
 * Body: { apiKey, apiSecret, symbol, quoteOrderQty }
 * WARNING: Sending secrets over the wire is only acceptable on localhost / trusted network.
 * Prefer client-side signing or a proper secret vault in production.
 */
router.post('/market-buy', async (req, res) => {
  try {
    const { apiKey, apiSecret, symbol, quoteOrderQty } = req.body;
    if (!apiKey || !apiSecret || !symbol || !quoteOrderQty) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const params = {
      symbol: symbol.toUpperCase(),
      side: 'BUY',
      type: 'MARKET',
      quoteOrderQty: String(quoteOrderQty),
      timestamp: Date.now(),
      recvWindow: 5000
    };

    const query = buildSignedQuery(params, apiSecret);
    const url = `https://api.binance.com/api/v3/order?${query}`;

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'X-MBX-APIKEY': apiKey,
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    const data = await response.json();
    if (!response.ok) {
      return res.status(response.status).json(data);
    }
    res.json(data);
  } catch (err) {
    console.error('Trade error:', err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
