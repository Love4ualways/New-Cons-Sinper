/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        dark: {
          900: '#0b0e11',
          800: '#12161c',
          700: '#1a1f27',
          600: '#242a33',
        }
      }
    },
  },
  plugins: [],
}
