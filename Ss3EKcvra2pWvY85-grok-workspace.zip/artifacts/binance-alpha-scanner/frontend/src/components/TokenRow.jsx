import React, { useState } from 'react'
import { ExternalLink, Zap, X } from 'lucide-react'

function formatAge(ms) {
  if (!ms) return '—'
  const sec = Math.floor((Date.now() - ms) / 1000)
  if (sec < 60) return `${sec}s`
  const min = Math.floor(sec / 60)
  if (min < 60) return `${min}m`
  const hr = Math.floor(min / 60)
  return `${hr}h ${min % 60}m`
}

function formatPrice(p) {
  if (p == null || isNaN(p)) return '—'
  if (p < 0.0001) return p.toExponential(2)
  if (p < 1) return p.toFixed(6)
  if (p < 100) return p.toFixed(4)
  return p.toFixed(2)
}

function formatPct(v) {
  if (v == null || isNaN(v)) return '—'
  const sign = v >= 0 ? '+' : ''
  return `${sign}${v.toFixed(2)}%`
}

function formatSize(v) {
  if (v == null) return '—'
  if (v >= 1e6) return `$${(v / 1e6).toFixed(2)}M`
  if (v >= 1e3) return `$${(v / 1e3).toFixed(1)}K`
  return `$${v.toFixed(0)}`
}

export default function TokenRow({ token, apiKey, apiSecret, onUpdatePosition, onClosePosition }) {
  const [buyAmount, setBuyAmount] = useState('20') // USDT
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState(null)

  const tradingSymbol = token.tokenId || token.alphaId
    ? `ALPHA_${token.tokenId || token.alphaId}USDT`
    : `${token.symbol}USDT`

  const chartUrl = `https://www.binance.com/en/trade/${tradingSymbol}`

  const age = formatAge(token.detectedAt)
  const price = formatPrice(token.price)
  const change24 = formatPct(token.priceChange24h)
  const gain = formatPct(token.gain)
  const sizeDisplay = token.size ? formatSize(token.size) : formatSize(token.liquidity || token.marketCap)

  const gainColor = token.gain > 0 ? 'text-emerald-400' : token.gain < 0 ? 'text-red-400' : 'text-gray-400'
  const changeColor = token.priceChange24h > 0 ? 'text-emerald-400' : token.priceChange24h < 0 ? 'text-red-400' : 'text-gray-400'

  async function handleBuy() {
    if (!apiKey || !apiSecret) {
      setMsg('Set API keys in Settings first')
      setTimeout(() => setMsg(null), 3000)
      return
    }
    const amount = parseFloat(buyAmount)
    if (!amount || amount <= 0) {
      setMsg('Invalid amount')
      return
    }

    setBusy(true)
    setMsg(null)

    try {
      // For security & simplicity we do a client-side signed request using the Binance Spot API.
      // In production you should use a secure backend proxy.
      // Here we demonstrate the flow and mark the position as opened.

      // NOTE: Real signing requires crypto.subtle or a library.
      // For this demo we simulate success and open the position locally.
      // Replace the simulation with real signed POST /api/v3/order when ready.

      console.log('Would place MARKET BUY', tradingSymbol, 'quoteOrderQty=', amount)

      // Simulate network
      await new Promise(r => setTimeout(r, 800))

      // Open position at current price
      const entry = token.price || 0
      onUpdatePosition(token.symbol, {
        entryPrice: entry,
        size: amount,
        trailingSL: entry * 0.92, // example -8% trailing
        status: 'open'
      })

      setMsg('Position opened (demo)')
      setTimeout(() => setMsg(null), 2500)
    } catch (err) {
      setMsg(err.message || 'Order failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <tr className="border-b border-dark-700 hover:bg-dark-800/60 transition-colors">
      {/* CHAIN */}
      <td className="px-3 py-2.5 whitespace-nowrap">
        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-dark-600 text-gray-300">
          {token.chainName || '—'}
        </span>
      </td>

      {/* COIN */}
      <td className="px-3 py-2.5 whitespace-nowrap">
        <a
          href={chartUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 text-yellow-400 hover:text-yellow-300 font-medium"
        >
          {token.symbol}
          <ExternalLink size={12} className="opacity-60" />
        </a>
        <div className="text-[10px] text-gray-500 truncate max-w-[120px]">{token.name}</div>
      </td>

      {/* AGE */}
      <td className="px-3 py-2.5 whitespace-nowrap text-gray-300 tabular-nums">
        {age}
      </td>

      {/* SIZE */}
      <td className="px-3 py-2.5 whitespace-nowrap text-gray-300 tabular-nums">
        {sizeDisplay}
      </td>

      {/* ENTRY ZONE */}
      <td className="px-3 py-2.5 whitespace-nowrap text-gray-400 tabular-nums text-xs">
        {token.entryPrice ? formatPrice(token.entryPrice) : '—'}
      </td>

      {/* CURRENT PRICE */}
      <td className="px-3 py-2.5 whitespace-nowrap font-medium tabular-nums">
        {price}
      </td>

      {/* GAIN */}
      <td className={`px-3 py-2.5 whitespace-nowrap font-medium tabular-nums ${gainColor}`}>
        {gain}
      </td>

      {/* 24H CHANGE */}
      <td className={`px-3 py-2.5 whitespace-nowrap tabular-nums ${changeColor}`}>
        {change24}
      </td>

      {/* TRAILING SL */}
      <td className="px-3 py-2.5 whitespace-nowrap text-gray-400 tabular-nums text-xs">
        {token.trailingSL ? formatPrice(token.trailingSL) : '—'}
      </td>

      {/* TP PROGRESS */}
      <td className="px-3 py-2.5 whitespace-nowrap">
        <div className="w-20 h-1.5 bg-dark-600 rounded-full overflow-hidden">
          <div
            className="h-full bg-emerald-500 rounded-full transition-all"
            style={{ width: `${Math.min(100, Math.max(0, token.tpProgress || 0))}%` }}
          />
        </div>
      </td>

      {/* SIGNALS */}
      <td className="px-3 py-2.5 whitespace-nowrap">
        {token.status === 'new' && (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-yellow-500/15 text-yellow-400">
            NEW
          </span>
        )}
        {token.status === 'open' && (
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-500/15 text-emerald-400">
            OPEN
          </span>
        )}
        {token.signals?.length > 0 && (
          <span className="ml-1 text-[10px] text-blue-400">{token.signals.join(', ')}</span>
        )}
      </td>

      {/* TRADE */}
      <td className="px-3 py-2.5 whitespace-nowrap">
        <div className="flex items-center gap-1">
          <input
            type="number"
            value={buyAmount}
            onChange={e => setBuyAmount(e.target.value)}
            className="w-14 px-1.5 py-1 text-xs bg-dark-700 border border-dark-600 rounded text-white focus:outline-none focus:border-yellow-500"
            placeholder="USDT"
            min="1"
            step="1"
          />
          <button
            onClick={handleBuy}
            disabled={busy}
            className="flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 disabled:opacity-50 transition"
          >
            <Zap size={12} />
            {busy ? '…' : 'Buy'}
          </button>
        </div>
        {msg && <div className="text-[10px] text-gray-400 mt-0.5">{msg}</div>}
      </td>

      {/* CLOSE */}
      <td className="px-3 py-2.5 whitespace-nowrap">
        {token.status === 'open' ? (
          <button
            onClick={() => onClosePosition(token.symbol)}
            className="p-1.5 rounded text-red-400 hover:bg-red-500/10 transition"
            title="Close position"
          >
            <X size={14} />
          </button>
        ) : (
          <span className="text-gray-600">—</span>
        )}
      </td>
    </tr>
  )
}
