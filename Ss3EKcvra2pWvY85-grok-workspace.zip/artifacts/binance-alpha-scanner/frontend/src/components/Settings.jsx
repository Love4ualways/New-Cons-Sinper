import React, { useState } from 'react'
import { X, Key, Filter } from 'lucide-react'

export default function Settings({ apiKey, apiSecret, filterAgeMinutes, onSaveKeys, onFilterChange, onClose }) {
  const [key, setKey] = useState(apiKey)
  const [secret, setSecret] = useState(apiSecret)
  const [age, setAge] = useState(filterAgeMinutes)

  function handleSave() {
    onSaveKeys(key.trim(), secret.trim())
    onFilterChange(Number(age) || 0)
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-dark-800 border border-dark-600 rounded-xl w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between px-5 py-4 border-b border-dark-600">
          <h2 className="text-lg font-semibold text-white">Settings</h2>
          <button onClick={onClose} className="p-1 rounded hover:bg-dark-600 text-gray-400">
            <X size={18} />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {/* API Keys */}
          <div>
            <div className="flex items-center gap-2 mb-3 text-sm font-medium text-gray-300">
              <Key size={16} /> Binance API Keys
            </div>
            <p className="text-xs text-gray-500 mb-3">
              Stored only in your browser localStorage. Used for one-click market buys.
              Create a key with <strong>Spot Trading</strong> permission only.
            </p>
            <div className="space-y-2">
              <input
                type="text"
                value={key}
                onChange={e => setKey(e.target.value)}
                placeholder="API Key"
                className="w-full px-3 py-2 text-sm bg-dark-700 border border-dark-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-yellow-500"
              />
              <input
                type="password"
                value={secret}
                onChange={e => setSecret(e.target.value)}
                placeholder="API Secret"
                className="w-full px-3 py-2 text-sm bg-dark-700 border border-dark-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-yellow-500"
              />
            </div>
          </div>

          {/* Age filter */}
          <div>
            <div className="flex items-center gap-2 mb-3 text-sm font-medium text-gray-300">
              <Filter size={16} /> Max Age Filter (minutes)
            </div>
            <p className="text-xs text-gray-500 mb-2">
              Only show coins detected within the last X minutes. Set 0 to show all.
            </p>
            <input
              type="number"
              value={age}
              onChange={e => setAge(e.target.value)}
              min="0"
              className="w-32 px-3 py-2 text-sm bg-dark-700 border border-dark-600 rounded-lg text-white focus:outline-none focus:border-yellow-500"
            />
          </div>
        </div>

        <div className="flex justify-end gap-3 px-5 py-4 border-t border-dark-600">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm rounded-lg text-gray-300 hover:bg-dark-600 transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 text-sm rounded-lg bg-yellow-500 text-black font-medium hover:bg-yellow-400 transition"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  )
}
