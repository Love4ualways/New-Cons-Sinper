import React from 'react'
import TokenRow from './TokenRow'

const COLUMNS = [
  { key: 'chain', label: 'CHAIN', width: '90px' },
  { key: 'coin', label: 'COIN', width: '140px' },
  { key: 'age', label: 'AGE', width: '90px' },
  { key: 'size', label: 'SIZE', width: '100px' },
  { key: 'entry', label: 'ENTRY ZONE', width: '110px' },
  { key: 'price', label: 'CURRENT PRICE', width: '120px' },
  { key: 'gain', label: 'GAIN', width: '90px' },
  { key: 'change24h', label: '24H CHANGE', width: '100px' },
  { key: 'trailing', label: 'TRAILING SL', width: '100px' },
  { key: 'tp', label: 'TP PROGRESS', width: '110px' },
  { key: 'signals', label: 'SIGNALS', width: '120px' },
  { key: 'trade', label: 'TRADE', width: '100px' },
  { key: 'close', label: 'CLOSE', width: '80px' },
]

export default function Dashboard({ tokens, apiKey, apiSecret, onUpdatePosition, onClosePosition }) {
  return (
    <div className="h-full flex flex-col">
      {/* Table header */}
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-sm">
          <thead className="sticky top-0 z-10 bg-dark-800 border-b border-dark-600">
            <tr>
              {COLUMNS.map(col => (
                <th
                  key={col.key}
                  className="px-3 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider whitespace-nowrap"
                  style={{ minWidth: col.width }}
                >
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tokens.length === 0 ? (
              <tr>
                <td colSpan={COLUMNS.length} className="px-4 py-16 text-center text-gray-500">
                  <div className="flex flex-col items-center gap-2">
                    <div className="text-4xl opacity-30">α</div>
                    <p>No open positions yet — waiting for a new token to pass the safety screen.</p>
                    <p className="text-xs text-gray-600 mt-1">
                      New Alpha coins will appear here automatically as soon as they are detected.
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              tokens.map(token => (
                <TokenRow
                  key={token.symbol}
                  token={token}
                  apiKey={apiKey}
                  apiSecret={apiSecret}
                  onUpdatePosition={onUpdatePosition}
                  onClosePosition={onClosePosition}
                />
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
