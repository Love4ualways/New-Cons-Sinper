import React, { useState, useEffect, useCallback } from 'react'
import { io } from 'socket.io-client'
import Dashboard from './components/Dashboard'
import Settings from './components/Settings'
import { Settings as SettingsIcon, Activity, Wifi, WifiOff } from 'lucide-react'

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:3001'

function App() {
  const [tokens, setTokens] = useState([])
  const [connected, setConnected] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('binance_api_key') || '')
  const [apiSecret, setApiSecret] = useState(() => localStorage.getItem('binance_api_secret') || '')
  const [filterAgeMinutes, setFilterAgeMinutes] = useState(60) // show only coins younger than X min
  const [socket, setSocket] = useState(null)

  useEffect(() => {
    const s = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 20
    })

    s.on('connect', () => {
      console.log('Connected to backend')
      setConnected(true)
    })

    s.on('disconnect', () => {
      setConnected(false)
    })

    s.on('snapshot', (data) => {
      setTokens(data || [])
    })

    s.on('new_token', (token) => {
      setTokens(prev => {
        const exists = prev.find(t => t.symbol === token.symbol)
        if (exists) return prev
        return [token, ...prev]
      })
    })

    s.on('token_update', (updated) => {
      setTokens(prev => prev.map(t => t.symbol === updated.symbol ? { ...t, ...updated } : t))
    })

    setSocket(s)

    return () => {
      s.disconnect()
    }
  }, [])

  const saveKeys = useCallback((key, secret) => {
    setApiKey(key)
    setApiSecret(secret)
    localStorage.setItem('binance_api_key', key)
    localStorage.setItem('binance_api_secret', secret)
  }, [])

  const updatePosition = useCallback((symbol, data) => {
    if (socket) {
      socket.emit('update_position', { symbol, ...data })
    }
    setTokens(prev => prev.map(t => {
      if (t.symbol !== symbol) return t
      const entry = data.entryPrice ?? t.entryPrice
      const price = t.price
      const gain = (entry && price) ? ((price - entry) / entry) * 100 : t.gain
      return { ...t, ...data, gain, status: 'open' }
    }))
  }, [socket])

  const closePosition = useCallback((symbol) => {
    if (socket) socket.emit('close_position', { symbol })
    setTokens(prev => prev.map(t => t.symbol === symbol
      ? { ...t, status: 'closed', entryPrice: null, size: null, gain: null }
      : t))
  }, [socket])

  // Filter by age
  const filteredTokens = tokens.filter(t => {
    if (!filterAgeMinutes) return true
    const ageMin = (Date.now() - (t.detectedAt || 0)) / 60000
    return ageMin <= filterAgeMinutes
  })

  return (
    <div className="min-h-screen bg-dark-900 flex flex-col">
      {/* Header */}
      <header className="border-b border-dark-600 bg-dark-800 px-4 py-3 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-yellow-500/20 flex items-center justify-center text-yellow-400 font-bold text-lg">
            α
          </div>
          <div>
            <h1 className="text-lg font-semibold text-white leading-tight">Binance Alpha Scanner</h1>
            <p className="text-xs text-gray-400">New launching coins • Live dashboard</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm">
            {connected ? (
              <span className="flex items-center gap-1.5 text-emerald-400">
                <Wifi size={16} /> Connected
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-red-400">
                <WifiOff size={16} /> Disconnected
              </span>
            )}
            <span className="text-gray-500">|</span>
            <span className="text-gray-400 flex items-center gap-1">
              <Activity size={14} /> {filteredTokens.length} coins
            </span>
          </div>

          <button
            onClick={() => setShowSettings(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-dark-600 hover:bg-dark-500 text-sm transition"
          >
            <SettingsIcon size={16} />
            Settings
          </button>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1 overflow-hidden">
        <Dashboard
          tokens={filteredTokens}
          apiKey={apiKey}
          apiSecret={apiSecret}
          onUpdatePosition={updatePosition}
          onClosePosition={closePosition}
        />
      </main>

      {/* Settings Modal */}
      {showSettings && (
        <Settings
          apiKey={apiKey}
          apiSecret={apiSecret}
          filterAgeMinutes={filterAgeMinutes}
          onSaveKeys={saveKeys}
          onFilterChange={setFilterAgeMinutes}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  )
}

export default App
