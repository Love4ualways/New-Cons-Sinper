import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/dashboard";
import { fetchAlphaTokens } from "@/lib/alpha/functions";

export const Route = createFileRoute("/")({
  loader: () => fetchAlphaTokens(),
  component: Home,
});

function Home() {
  const initialTokens = Route.useLoaderData();
  return <Dashboard initialTokens={initialTokens} />;
}
