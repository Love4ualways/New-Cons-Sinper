import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { AlphaToken } from "./types";

export const fetchAlphaTokens = createServerFn({ method: "GET" }).handler(
  async (): Promise<AlphaToken[]> => {
    const { loadTokens } = await import("./alpha.server");
    return loadTokens();
  },
);

const buySchema = z.object({
  apiKey: z.string().min(8),
  apiSecret: z.string().min(8),
  symbol: z.string().min(3),
  quoteOrderQty: z.number().positive(),
});

export const placeMarketBuy = createServerFn({ method: "POST" })
  .validator(buySchema)
  .handler(async ({ data }) => {
    const { submitMarketBuy } = await import("./alpha.server");
    return submitMarketBuy(data);
  });
