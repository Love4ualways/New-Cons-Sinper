export type AlphaToken = {
  tokenId: string;
  alphaId: string;
  symbol: string;
  name: string;
  chainId: string;
  chainName: string;
  chainIconUrl: string | null;
  contractAddress: string;
  iconUrl: string | null;
  price: number;
  percentChange24h: number;
  volume24h: number;
  marketCap: number;
  fdv: number;
  liquidity: number;
  holders: number;
  listingTime: number;
  listingCex: boolean;
  offline: boolean;
  offsell: boolean;
  fullyDelisted: boolean;
  hotTag: boolean;
  tradeSymbol: string;
};

export type Position = {
  symbol: string;
  alphaId: string;
  tradeSymbol: string;
  entryPrice: number;
  sizeUsdt: number;
  qty: number;
  trailingSl: number;
  peakPrice: number;
  openedAt: number;
  paper: boolean;
  orderId?: string;
};

export type ScannerSettings = {
  apiKey: string;
  apiSecret: string;
  paperTrading: boolean;
  defaultBuyUsdt: number;
  maxAgeHours: number;
  minLiquidity: number;
  trailPct: number;
  tpPct: number;
};
