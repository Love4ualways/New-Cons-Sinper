import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { Position, ScannerSettings } from "./types";

const DEFAULT_SETTINGS: ScannerSettings = {
  apiKey: "",
  apiSecret: "",
  paperTrading: true,
  defaultBuyUsdt: 20,
  maxAgeHours: 168,
  minLiquidity: 10000,
  trailPct: 8,
  tpPct: 25,
};

type ScannerState = {
  settings: ScannerSettings;
  positions: Record<string, Position>;
  seenIds: string[];
  updateSettings: (patch: Partial<ScannerSettings>) => void;
  openPosition: (position: Position) => void;
  closePosition: (symbol: string) => void;
  markSeen: (ids: string[]) => void;
  applyLivePrices: (prices: Record<string, number>, trailPct: number) => void;
};

export const useScannerStore = create<ScannerState>()(
  persist(
    (set) => ({
      settings: DEFAULT_SETTINGS,
      positions: {},
      seenIds: [],
      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),
      openPosition: (position) =>
        set((s) => ({
          positions: { ...s.positions, [position.symbol]: position },
        })),
      closePosition: (symbol) =>
        set((s) => {
          const next = { ...s.positions };
          delete next[symbol];
          return { positions: next };
        }),
      markSeen: (ids) =>
        set((s) => {
          const merged = new Set([...s.seenIds, ...ids]);
          return { seenIds: Array.from(merged).slice(-2000) };
        }),
      applyLivePrices: (prices, trailPct) =>
        set((s) => {
          const next = { ...s.positions };
          let changed = false;
          for (const pos of Object.values(next)) {
            const price = prices[pos.symbol];
            if (!price) continue;
            const peak = Math.max(pos.peakPrice, price);
            const trail = peak * (1 - trailPct / 100);
            if (peak !== pos.peakPrice || trail !== pos.trailingSl) {
              next[pos.symbol] = { ...pos, peakPrice: peak, trailingSl: trail };
              changed = true;
            }
          }
          return changed ? { positions: next } : s;
        }),
    }),
    {
      name: "alpha-scanner",
      skipHydration: true,
      storage: createJSONStorage(() => localStorage),
    },
  ),
);
