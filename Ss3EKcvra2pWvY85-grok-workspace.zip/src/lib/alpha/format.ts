const CHAIN_SLUG: Record<string, string> = {
  BSC: "bsc",
  Ethereum: "ethereum",
  Solana: "solana",
  Base: "base",
  Arbitrum: "arbitrum",
  Linea: "linea",
  Sonic: "sonic",
  TRON: "tron",
  Sui: "sui",
  Robinhood: "robinhood",
};

export function chainSlug(chainName: string, chainId: string) {
  return CHAIN_SLUG[chainName] ?? chainId.toLowerCase();
}

export function chartUrl(token: {
  alphaId: string;
  chainName: string;
  chainId: string;
  contractAddress: string;
}) {
  if (token.contractAddress) {
    return `https://www.binance.com/en/alpha/${chainSlug(token.chainName, token.chainId)}/${token.contractAddress}`;
  }
  return `https://www.binance.com/en/trade/${token.alphaId}USDT`;
}

export function formatPrice(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "—";
  const abs = Math.abs(value);
  if (abs === 0) return "0";
  if (abs < 0.0001) return value.toExponential(2);
  if (abs < 1) return value.toPrecision(4);
  if (abs < 100) return value.toFixed(4);
  return value.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

export function formatUsd(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "—";
  const abs = Math.abs(value);
  if (abs >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
  if (abs >= 1e3) return `$${(value / 1e3).toFixed(1)}K`;
  if (abs >= 1) return `$${value.toFixed(0)}`;
  return `$${value.toFixed(2)}`;
}

export function formatPct(value: number | null | undefined) {
  if (value == null || !Number.isFinite(value)) return "—";
  const sign = value > 0 ? "+" : "";
  return `${sign}${value.toFixed(2)}%`;
}

export function formatAge(listingTime: number, now = Date.now()) {
  if (!listingTime) return "—";
  const sec = Math.max(0, Math.floor((now - listingTime) / 1000));
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m`;
  const hr = Math.floor(min / 60);
  if (hr < 48) return `${hr}h ${min % 60}m`;
  const days = Math.floor(hr / 24);
  return `${days}d`;
}

export function num(value: unknown) {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}
