import { useState } from "react";
import { ExternalLink, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import type { AlphaToken, Position } from "@/lib/alpha/types";
import {
  chartUrl,
  formatAge,
  formatPct,
  formatPrice,
  formatUsd,
} from "@/lib/alpha/format";
import { placeMarketBuy } from "@/lib/alpha/functions";
import { useScannerStore } from "@/lib/alpha/store";
import { cn } from "@/lib/utils";

const COLUMNS = [
  { key: "chain", label: "Chain" },
  { key: "coin", label: "Coin" },
  { key: "age", label: "Age" },
  { key: "size", label: "Size" },
  { key: "entry", label: "Entry zone" },
  { key: "price", label: "Current price" },
  { key: "gain", label: "Gain" },
  { key: "change", label: "24h change" },
  { key: "sl", label: "Trailing SL" },
  { key: "tp", label: "TP progress" },
  { key: "signals", label: "Signals" },
  { key: "trade", label: "Trade" },
  { key: "close", label: "Close" },
] as const;

export function TokenTableHeader() {
  return (
    <thead className="sticky top-0 z-10 bg-surface">
      <tr className="border-b border-border">
        {COLUMNS.map((col) => (
          <th
            key={col.key}
            className="whitespace-nowrap px-3 py-3 text-left text-[11px] font-medium uppercase tracking-wider text-muted"
          >
            {col.label}
          </th>
        ))}
      </tr>
    </thead>
  );
}

export function TokenRow({
  token,
  position,
  now,
}: {
  token: AlphaToken;
  position?: Position;
  now: number;
}) {
  const settings = useScannerStore((s) => s.settings);
  const openPosition = useScannerStore((s) => s.openPosition);
  const closePosition = useScannerStore((s) => s.closePosition);
  const [amount, setAmount] = useState(String(settings.defaultBuyUsdt));
  const [busy, setBusy] = useState(false);

  const gain =
    position && token.price
      ? ((token.price - position.entryPrice) / position.entryPrice) * 100
      : null;
  const tpProgress =
    gain != null ? Math.max(0, Math.min(100, (gain / settings.tpPct) * 100)) : 0;
  const ageMs = now - token.listingTime;
  const isNew = ageMs < 2 * 60 * 60 * 1000;

  async function buy() {
    const quote = Number(amount);
    if (!Number.isFinite(quote) || quote <= 0) {
      toast.error("Enter a valid USDT size");
      return;
    }
    setBusy(true);
    try {
      let qty = quote / Math.max(token.price, 1e-12);
      let orderId: string | undefined;
      if (!settings.paperTrading) {
        if (!settings.apiKey || !settings.apiSecret) {
          throw new Error("Add Binance API keys in Settings, or keep paper trading on.");
        }
        const result = await placeMarketBuy({
          data: {
            apiKey: settings.apiKey,
            apiSecret: settings.apiSecret,
            symbol: token.tradeSymbol,
            quoteOrderQty: quote,
          },
        });
        orderId = result.orderId;
        if (result.executedQty) qty = result.executedQty;
      }
      const entry = token.price;
      openPosition({
        symbol: token.symbol,
        alphaId: token.alphaId,
        tradeSymbol: token.tradeSymbol,
        entryPrice: entry,
        sizeUsdt: quote,
        qty,
        trailingSl: entry * (1 - settings.trailPct / 100),
        peakPrice: entry,
        openedAt: Date.now(),
        paper: settings.paperTrading,
        orderId,
      });
      toast.success(
        settings.paperTrading
          ? `Paper bought ${token.symbol}`
          : `Bought ${token.symbol}`,
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Buy failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <tr className="border-b border-border/70 hover:bg-surface-2/60">
      <td className="px-3 py-2.5">
        <Badge>{token.chainName}</Badge>
      </td>
      <td className="px-3 py-2.5">
        <a
          href={chartUrl(token)}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 font-medium text-fg hover:text-accent"
        >
          {token.symbol}
          <ExternalLink className="size-3 opacity-50" />
        </a>
        <div className="max-w-32 truncate text-[11px] text-subtle">{token.name}</div>
      </td>
      <td className="px-3 py-2.5 font-mono text-xs tabular-nums text-fg">
        {formatAge(token.listingTime, now)}
      </td>
      <td className="px-3 py-2.5 font-mono text-xs tabular-nums text-fg">
        {position ? formatUsd(position.sizeUsdt) : formatUsd(token.liquidity)}
      </td>
      <td className="px-3 py-2.5 font-mono text-xs tabular-nums text-muted">
        {position ? formatPrice(position.entryPrice) : "—"}
      </td>
      <td className="px-3 py-2.5 font-mono text-xs tabular-nums text-fg">
        {formatPrice(token.price)}
      </td>
      <td
        className={cn(
          "px-3 py-2.5 font-mono text-xs tabular-nums",
          gain == null
            ? "text-muted"
            : gain >= 0
              ? "text-buy"
              : "text-sell",
        )}
      >
        {formatPct(gain)}
      </td>
      <td
        className={cn(
          "px-3 py-2.5 font-mono text-xs tabular-nums",
          token.percentChange24h >= 0 ? "text-buy" : "text-sell",
        )}
      >
        {formatPct(token.percentChange24h)}
      </td>
      <td className="px-3 py-2.5 font-mono text-xs tabular-nums text-muted">
        {position ? formatPrice(position.trailingSl) : "—"}
      </td>
      <td className="px-3 py-2.5">
        <div className="h-1.5 w-20 overflow-hidden rounded-full bg-surface-2">
          <div
            className="h-full rounded-full bg-buy transition-[width] duration-300"
            style={{ width: `${tpProgress}%` }}
          />
        </div>
      </td>
      <td className="px-3 py-2.5">
        <div className="flex flex-wrap gap-1">
          {isNew && (
            <Badge className="border-accent/30 bg-accent/10 text-accent">NEW</Badge>
          )}
          {position && (
            <Badge className="border-buy/30 bg-buy/10 text-buy">
              {position.paper ? "PAPER" : "OPEN"}
            </Badge>
          )}
          {token.hotTag && <Badge>HOT</Badge>}
          {token.listingCex && <Badge>CEX</Badge>}
        </div>
      </td>
      <td className="px-3 py-2.5">
        <div className="flex items-center gap-1">
          <Input
            type="number"
            min={1}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="h-9 w-16 px-2 text-xs"
            aria-label={`Buy size for ${token.symbol}`}
          />
          <Button
            variant="buy"
            size="sm"
            className="min-h-9"
            disabled={busy}
            onClick={buy}
          >
            {busy ? "…" : "Buy"}
          </Button>
        </div>
      </td>
      <td className="px-3 py-2.5">
        {position ? (
          <Button
            variant="ghost"
            size="icon"
            className="size-9 text-sell"
            aria-label={`Close ${token.symbol}`}
            onClick={() => closePosition(token.symbol)}
          >
            <X className="size-4" />
          </Button>
        ) : (
          <span className="text-subtle">—</span>
        )}
      </td>
    </tr>
  );
}

export function TokenCard({
  token,
  position,
  now,
}: {
  token: AlphaToken;
  position?: Position;
  now: number;
}) {
  const settings = useScannerStore((s) => s.settings);
  const openPosition = useScannerStore((s) => s.openPosition);
  const closePosition = useScannerStore((s) => s.closePosition);
  const [amount, setAmount] = useState(String(settings.defaultBuyUsdt));
  const [busy, setBusy] = useState(false);

  const gain =
    position && token.price
      ? ((token.price - position.entryPrice) / position.entryPrice) * 100
      : null;
  const isNew = now - token.listingTime < 2 * 60 * 60 * 1000;

  async function buy() {
    const quote = Number(amount);
    if (!Number.isFinite(quote) || quote <= 0) {
      toast.error("Enter a valid USDT size");
      return;
    }
    setBusy(true);
    try {
      let qty = quote / Math.max(token.price, 1e-12);
      let orderId: string | undefined;
      if (!settings.paperTrading) {
        if (!settings.apiKey || !settings.apiSecret) {
          throw new Error("Add Binance API keys in Settings, or keep paper trading on.");
        }
        const result = await placeMarketBuy({
          data: {
            apiKey: settings.apiKey,
            apiSecret: settings.apiSecret,
            symbol: token.tradeSymbol,
            quoteOrderQty: quote,
          },
        });
        orderId = result.orderId;
        if (result.executedQty) qty = result.executedQty;
      }
      const entry = token.price;
      openPosition({
        symbol: token.symbol,
        alphaId: token.alphaId,
        tradeSymbol: token.tradeSymbol,
        entryPrice: entry,
        sizeUsdt: quote,
        qty,
        trailingSl: entry * (1 - settings.trailPct / 100),
        peakPrice: entry,
        openedAt: Date.now(),
        paper: settings.paperTrading,
        orderId,
      });
      toast.success(
        settings.paperTrading ? `Paper bought ${token.symbol}` : `Bought ${token.symbol}`,
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Buy failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <article className="rounded-xl border border-border bg-surface p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <a
            href={chartUrl(token)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 font-semibold text-fg"
          >
            {token.symbol}
            <ExternalLink className="size-3.5 opacity-50" />
          </a>
          <p className="text-xs text-muted">
            {token.chainName} · {formatAge(token.listingTime, now)}
          </p>
        </div>
        <div className="text-right">
          <p className="font-mono text-sm tabular-nums">{formatPrice(token.price)}</p>
          <p
            className={cn(
              "font-mono text-xs tabular-nums",
              token.percentChange24h >= 0 ? "text-buy" : "text-sell",
            )}
          >
            {formatPct(token.percentChange24h)}
          </p>
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-1">
        {isNew && (
          <Badge className="border-accent/30 bg-accent/10 text-accent">NEW</Badge>
        )}
        {position && (
          <Badge className="border-buy/30 bg-buy/10 text-buy">
            {position.paper ? "PAPER" : "OPEN"} {formatPct(gain)}
          </Badge>
        )}
        <Badge>Liq {formatUsd(token.liquidity)}</Badge>
      </div>
      <div className="mt-3 flex items-center gap-2">
        <Input
          type="number"
          min={1}
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="h-11 flex-1"
          aria-label={`Buy size for ${token.symbol}`}
        />
        <Button variant="buy" className="h-11 min-w-20" disabled={busy} onClick={buy}>
          {busy ? "…" : "Buy"}
        </Button>
        {position && (
          <Button
            variant="sell"
            className="h-11"
            onClick={() => closePosition(token.symbol)}
          >
            Close
          </Button>
        )}
      </div>
    </article>
  );
}

