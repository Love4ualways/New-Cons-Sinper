import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Activity, Radio, Settings2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { SettingsDialog } from "@/components/settings-dialog";
import { TokenCard, TokenRow, TokenTableHeader } from "@/components/token-row";
import { fetchAlphaTokens } from "@/lib/alpha/functions";
import type { AlphaToken } from "@/lib/alpha/types";
import { useScannerStore } from "@/lib/alpha/store";

export function Dashboard({ initialTokens }: { initialTokens: AlphaToken[] }) {
  const [hydrated, setHydrated] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const settings = useScannerStore((s) => s.settings);
  const positions = useScannerStore((s) => s.positions);
  const seenIds = useScannerStore((s) => s.seenIds);
  const markSeen = useScannerStore((s) => s.markSeen);
  const applyLivePrices = useScannerStore((s) => s.applyLivePrices);

  useEffect(() => {
    const result = useScannerStore.persist.rehydrate();
    void Promise.resolve(result).then(() => setHydrated(true));
  }, []);

  const query = useQuery({
    queryKey: ["alpha-tokens"],
    queryFn: () => fetchAlphaTokens(),
    initialData: initialTokens,
    refetchInterval: 2000,
  });

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const tokens = query.data ?? [];

  useEffect(() => {
    if (!hydrated || !tokens.length) return;
    const prices: Record<string, number> = {};
    for (const t of tokens) prices[t.symbol] = t.price;
    applyLivePrices(prices, settings.trailPct);
  }, [hydrated, tokens, applyLivePrices, settings.trailPct]);

  useEffect(() => {
    if (!hydrated || !tokens.length) return;
    const known = new Set(seenIds);
    const fresh = tokens.filter((t) => !known.has(t.alphaId));
    if (seenIds.length && fresh.length) {
      for (const t of fresh.slice(0, 5)) {
        toast.message(`New Alpha listing: ${t.symbol}`, {
          description: `${t.chainName} · ${t.name}`,
        });
      }
    }
    if (fresh.length) markSeen(fresh.map((t) => t.alphaId));
    else if (!seenIds.length) markSeen(tokens.map((t) => t.alphaId));
  }, [hydrated, tokens, seenIds, markSeen]);

  const visible = useMemo(() => {
    const maxAgeMs = settings.maxAgeHours * 3600_000;
    const openSymbols = new Set(Object.keys(positions));
    const passed = tokens.filter((t) =>
      passesScreen(t, now, settings.minLiquidity, maxAgeMs),
    );
    const extras = tokens.filter(
      (t) => openSymbols.has(t.symbol) && !passed.some((p) => p.symbol === t.symbol),
    );
    return [...extras, ...passed].sort((a, b) => {
      const ao = openSymbols.has(a.symbol) ? 1 : 0;
      const bo = openSymbols.has(b.symbol) ? 1 : 0;
      if (ao !== bo) return bo - ao;
      return b.listingTime - a.listingTime;
    });
  }, [tokens, positions, now, settings.maxAgeHours, settings.minLiquidity]);

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/95 px-4 py-3 backdrop-blur-sm">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-lg border border-border bg-surface font-mono text-sm text-accent">
              α
            </span>
            <div className="min-w-0">
              <h1 className="truncate text-sm font-semibold tracking-tight">
                Alpha Launch Desk
              </h1>
              <p className="truncate text-xs text-muted">
                New Binance Alpha listings · live safety screen
              </p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 sm:gap-3">
          <StatusChip
            ok={!query.isError}
            label={
              query.isError ? "Feed down" : query.isFetching ? "Syncing" : "Live"
            }
          />
          <span className="hidden items-center gap-1 text-xs text-muted sm:inline-flex">
            <Activity className="size-3.5" />
            {visible.length} shown
          </span>
          <Button
            variant="outline"
            size="sm"
            className="min-h-10"
            onClick={() => setSettingsOpen(true)}
          >
            <Settings2 className="size-4" />
            Settings
          </Button>
        </div>
      </header>

      <main className="flex-1 overflow-auto">
        {query.isError ? (
          <Empty
            title="Could not reach Binance Alpha"
            body={query.error instanceof Error ? query.error.message : "Retrying…"}
          />
        ) : query.isLoading ? (
          <Empty title="Loading Alpha feed" body="Pulling the official token list." />
        ) : visible.length === 0 ? (
          <Empty
            title="No open positions yet — waiting for a new token to pass the safety screen."
            body={`Filter: last ${settings.maxAgeHours || "∞"}h · min liquidity $${settings.minLiquidity.toLocaleString()}. New listings appear here automatically.`}
          />
        ) : (
          <>
            <div className="hidden md:block">
              <table className="w-full min-w-[1100px] text-sm">
                <TokenTableHeader />
                <tbody>
                  {visible.map((token) => (
                    <TokenRow
                      key={token.alphaId}
                      token={token}
                      position={positions[token.symbol]}
                      now={now}
                    />
                  ))}
                </tbody>
              </table>
            </div>
            <div className="space-y-3 p-3 md:hidden">
              {visible.map((token) => (
                <TokenCard
                  key={token.alphaId}
                  token={token}
                  position={positions[token.symbol]}
                  now={now}
                />
              ))}
            </div>
          </>
        )}
      </main>

      {settingsOpen && <SettingsDialog onClose={() => setSettingsOpen(false)} />}
    </div>
  );
}

function passesScreen(
  token: AlphaToken,
  now: number,
  minLiquidity: number,
  maxAgeMs: number,
) {
  if (token.offline || token.offsell || token.fullyDelisted) return false;
  if (!token.contractAddress) return false;
  if (token.liquidity < minLiquidity) return false;
  if (maxAgeMs > 0 && now - token.listingTime > maxAgeMs) return false;
  return true;
}

function StatusChip({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-surface px-2.5 py-1 text-xs text-muted">
      <Radio className={ok ? "size-3.5 text-buy" : "size-3.5 text-sell"} />
      {label}
    </span>
  );
}

function Empty({ title, body }: { title: string; body: string }) {
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center px-6 py-24 text-center">
      <span className="mb-4 grid size-12 place-items-center rounded-2xl border border-border bg-surface font-mono text-lg text-muted">
        α
      </span>
      <p className="text-sm text-fg">{title}</p>
      <p className="mt-2 text-xs leading-relaxed text-muted">{body}</p>
    </div>
  );
}
