import { useState, type ReactNode } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useScannerStore } from "@/lib/alpha/store";

export function SettingsDialog({ onClose }: { onClose: () => void }) {
  const settings = useScannerStore((s) => s.settings);
  const updateSettings = useScannerStore((s) => s.updateSettings);
  const [draft, setDraft] = useState(settings);

  function save() {
    updateSettings({
      ...draft,
      defaultBuyUsdt: Number(draft.defaultBuyUsdt) || 20,
      maxAgeHours: Math.max(0, Number(draft.maxAgeHours) || 0),
      minLiquidity: Math.max(0, Number(draft.minLiquidity) || 0),
      trailPct: Math.max(0.1, Number(draft.trailPct) || 8),
      tpPct: Math.max(1, Number(draft.tpPct) || 25),
    });
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-3 sm:items-center">
      <div
        role="dialog"
        aria-labelledby="settings-title"
        className="w-full max-w-lg rounded-2xl border border-border bg-surface p-5 shadow-xl"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 id="settings-title" className="text-base font-semibold text-fg">
            Settings
          </h2>
          <Button variant="ghost" size="icon" className="size-9" onClick={onClose} aria-label="Close">
            <X className="size-4" />
          </Button>
        </div>

        <div className="space-y-4">
          <section>
            <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted">
              Binance API
            </p>
            <p className="mb-3 text-xs leading-relaxed text-subtle">
              Keys stay in this browser only. Use a Spot-only key. Live buys
              hit Binance market orders on ALPHA_*USDT pairs.
            </p>
            <div className="space-y-2">
              <Input
                placeholder="API key"
                value={draft.apiKey}
                onChange={(e) => setDraft({ ...draft, apiKey: e.target.value })}
                autoComplete="off"
              />
              <Input
                type="password"
                placeholder="API secret"
                value={draft.apiSecret}
                onChange={(e) => setDraft({ ...draft, apiSecret: e.target.value })}
                autoComplete="off"
              />
            </div>
            <label className="mt-3 flex min-h-11 items-center gap-2 text-sm text-fg">
              <input
                type="checkbox"
                checked={draft.paperTrading}
                onChange={(e) =>
                  setDraft({ ...draft, paperTrading: e.target.checked })
                }
                className="size-4 accent-accent"
              />
              Paper trading (simulate fills, no live order)
            </label>
          </section>

          <section className="grid grid-cols-2 gap-3">
            <Field label="Default buy (USDT)">
              <Input
                type="number"
                min={1}
                value={draft.defaultBuyUsdt}
                onChange={(e) =>
                  setDraft({ ...draft, defaultBuyUsdt: Number(e.target.value) })
                }
              />
            </Field>
            <Field label="Max age (hours, 0 = all)">
              <Input
                type="number"
                min={0}
                value={draft.maxAgeHours}
                onChange={(e) =>
                  setDraft({ ...draft, maxAgeHours: Number(e.target.value) })
                }
              />
            </Field>
            <Field label="Min liquidity (USD)">
              <Input
                type="number"
                min={0}
                value={draft.minLiquidity}
                onChange={(e) =>
                  setDraft({ ...draft, minLiquidity: Number(e.target.value) })
                }
              />
            </Field>
            <Field label="Trailing SL %">
              <Input
                type="number"
                min={0.1}
                step={0.1}
                value={draft.trailPct}
                onChange={(e) =>
                  setDraft({ ...draft, trailPct: Number(e.target.value) })
                }
              />
            </Field>
            <Field label="Take profit %">
              <Input
                type="number"
                min={1}
                step={1}
                value={draft.tpPct}
                onChange={(e) =>
                  setDraft({ ...draft, tpPct: Number(e.target.value) })
                }
              />
            </Field>
          </section>
        </div>

        <div className="mt-5 flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save}>Save</Button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block space-y-1.5 text-xs text-muted">
      <span>{label}</span>
      {children}
    </label>
  );
}
