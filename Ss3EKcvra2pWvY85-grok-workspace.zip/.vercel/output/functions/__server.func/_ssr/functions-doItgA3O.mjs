import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as string, n as number, r as object } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-doItgA3O.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var fetchAlphaTokens_createServerFn_handler = createServerRpc({
	id: "351bd4d988bd1a2e399af16145b0423f15508264637fc4ebcc6c8de876d6bdb0",
	name: "fetchAlphaTokens",
	filename: "src/lib/alpha/functions.ts"
}, (opts) => fetchAlphaTokens.__executeServer(opts));
var fetchAlphaTokens = createServerFn({ method: "GET" }).handler(fetchAlphaTokens_createServerFn_handler, async () => {
	const { loadTokens } = await import("./alpha.server-D8N4Q4yt.mjs");
	return loadTokens();
});
var buySchema = object({
	apiKey: string().min(8),
	apiSecret: string().min(8),
	symbol: string().min(3),
	quoteOrderQty: number().positive()
});
var placeMarketBuy_createServerFn_handler = createServerRpc({
	id: "023d382fc9141e700be6aed9126c724f8c9e256146ebada1df8e80906e30b833",
	name: "placeMarketBuy",
	filename: "src/lib/alpha/functions.ts"
}, (opts) => placeMarketBuy.__executeServer(opts));
var placeMarketBuy = createServerFn({ method: "POST" }).validator(buySchema).handler(placeMarketBuy_createServerFn_handler, async ({ data }) => {
	const { submitMarketBuy } = await import("./alpha.server-D8N4Q4yt.mjs");
	return submitMarketBuy(data);
});
//#endregion
export { fetchAlphaTokens_createServerFn_handler, placeMarketBuy_createServerFn_handler };
