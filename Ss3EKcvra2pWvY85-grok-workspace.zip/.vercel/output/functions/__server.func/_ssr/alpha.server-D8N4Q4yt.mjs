import { o as num } from "./format-Cyjj965a.mjs";
import { createHmac } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/alpha.server-D8N4Q4yt.js
var TOKEN_LIST_URL = "https://www.binance.com/bapi/defi/v1/public/wallet-direct/buw/wallet/cex/alpha/all/token/list";
var cache = null;
var CACHE_MS = 1500;
function mapToken(raw) {
	const symbol = String(raw.symbol ?? "").toUpperCase();
	const alphaId = String(raw.alphaId ?? "");
	if (!symbol || !alphaId) return null;
	return {
		tokenId: String(raw.tokenId ?? ""),
		alphaId,
		symbol,
		name: String(raw.name ?? symbol),
		chainId: String(raw.chainId ?? ""),
		chainName: String(raw.chainName ?? "Unknown"),
		chainIconUrl: raw.chainIconUrl ? String(raw.chainIconUrl) : null,
		contractAddress: String(raw.contractAddress ?? ""),
		iconUrl: raw.iconUrl ? String(raw.iconUrl) : null,
		price: num(raw.price),
		percentChange24h: num(raw.percentChange24h),
		volume24h: num(raw.volume24h),
		marketCap: num(raw.marketCap),
		fdv: num(raw.fdv),
		liquidity: num(raw.liquidity),
		holders: num(raw.holders),
		listingTime: num(raw.listingTime),
		listingCex: Boolean(raw.listingCex),
		offline: Boolean(raw.offline),
		offsell: Boolean(raw.offsell),
		fullyDelisted: Boolean(raw.fullyDelisted),
		hotTag: Boolean(raw.hotTag),
		tradeSymbol: `${alphaId}USDT`
	};
}
async function loadTokens() {
	if (cache && Date.now() - cache.at < CACHE_MS) return cache.tokens;
	const res = await fetch(TOKEN_LIST_URL, { headers: {
		Accept: "application/json",
		"User-Agent": "AlphaScanner/1.0"
	} });
	if (!res.ok) throw new Error(`Alpha token list failed (${res.status})`);
	const json = await res.json();
	if (!json.success || !Array.isArray(json.data)) throw new Error("Alpha token list returned an unexpected payload");
	const tokens = json.data.map(mapToken).filter((t) => t !== null).sort((a, b) => b.listingTime - a.listingTime);
	cache = {
		at: Date.now(),
		tokens
	};
	return tokens;
}
function signedQuery(params, secret) {
	const qs = new URLSearchParams(params).toString();
	return `${qs}&signature=${createHmac("sha256", secret).update(qs).digest("hex")}`;
}
async function submitMarketBuy(input) {
	const query = signedQuery({
		symbol: input.symbol.toUpperCase(),
		side: "BUY",
		type: "MARKET",
		quoteOrderQty: String(input.quoteOrderQty),
		timestamp: String(Date.now()),
		recvWindow: "5000"
	}, input.apiSecret);
	const res = await fetch(`https://api.binance.com/api/v3/order?${query}`, {
		method: "POST",
		headers: { "X-MBX-APIKEY": input.apiKey }
	});
	const body = await res.json();
	if (!res.ok) {
		const msg = typeof body.msg === "string" ? body.msg : `Order rejected (${res.status})`;
		throw new Error(msg);
	}
	return {
		orderId: String(body.orderId ?? ""),
		symbol: String(body.symbol ?? input.symbol),
		executedQty: num(body.executedQty),
		cummulativeQuoteQty: num(body.cummulativeQuoteQty),
		status: String(body.status ?? "")
	};
}
//#endregion
export { loadTokens, submitMarketBuy };
