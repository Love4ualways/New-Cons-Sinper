//#region node_modules/.nitro/vite/services/ssr/assets/format-Cyjj965a.js
var CHAIN_SLUG = {
	BSC: "bsc",
	Ethereum: "ethereum",
	Solana: "solana",
	Base: "base",
	Arbitrum: "arbitrum",
	Linea: "linea",
	Sonic: "sonic",
	TRON: "tron",
	Sui: "sui",
	Robinhood: "robinhood"
};
function chainSlug(chainName, chainId) {
	return CHAIN_SLUG[chainName] ?? chainId.toLowerCase();
}
function chartUrl(token) {
	if (token.contractAddress) return `https://www.binance.com/en/alpha/${chainSlug(token.chainName, token.chainId)}/${token.contractAddress}`;
	return `https://www.binance.com/en/trade/${token.alphaId}USDT`;
}
function formatPrice(value) {
	if (value == null || !Number.isFinite(value)) return "—";
	const abs = Math.abs(value);
	if (abs === 0) return "0";
	if (abs < 1e-4) return value.toExponential(2);
	if (abs < 1) return value.toPrecision(4);
	if (abs < 100) return value.toFixed(4);
	return value.toLocaleString(void 0, { maximumFractionDigits: 2 });
}
function formatUsd(value) {
	if (value == null || !Number.isFinite(value)) return "—";
	const abs = Math.abs(value);
	if (abs >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
	if (abs >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
	if (abs >= 1e3) return `$${(value / 1e3).toFixed(1)}K`;
	if (abs >= 1) return `$${value.toFixed(0)}`;
	return `$${value.toFixed(2)}`;
}
function formatPct(value) {
	if (value == null || !Number.isFinite(value)) return "—";
	return `${value > 0 ? "+" : ""}${value.toFixed(2)}%`;
}
function formatAge(listingTime, now = Date.now()) {
	if (!listingTime) return "—";
	const sec = Math.max(0, Math.floor((now - listingTime) / 1e3));
	if (sec < 60) return `${sec}s`;
	const min = Math.floor(sec / 60);
	if (min < 60) return `${min}m`;
	const hr = Math.floor(min / 60);
	if (hr < 48) return `${hr}h ${min % 60}m`;
	return `${Math.floor(hr / 24)}d`;
}
function num(value) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : 0;
}
//#endregion
export { formatUsd as a, formatPrice as i, formatAge as n, num as o, formatPct as r, chartUrl as t };
