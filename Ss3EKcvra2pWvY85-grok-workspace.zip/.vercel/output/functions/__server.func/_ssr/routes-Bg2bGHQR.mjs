import { i as __toESM } from "../_runtime.mjs";
import { a as formatUsd, i as formatPrice, n as formatAge, r as formatPct, t as chartUrl } from "./format-Cyjj965a.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { a as ExternalLink, i as Radio, o as Activity, r as Settings2, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as placeMarketBuy, n as Route, r as fetchAlphaTokens } from "./router-BTL3OoEl.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bg2bGHQR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-1.5 whitespace-nowrap rounded-md font-medium transition-colors duration-150 disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50", {
	variants: {
		variant: {
			default: "bg-fg text-bg hover:bg-fg/90",
			accent: "bg-accent text-bg hover:bg-accent/90",
			buy: "bg-buy text-bg hover:bg-buy/90",
			sell: "bg-sell/15 text-sell hover:bg-sell/25",
			ghost: "bg-transparent text-muted hover:bg-surface-2 hover:text-fg",
			outline: "border border-border bg-transparent text-fg hover:bg-surface-2"
		},
		size: {
			default: "h-10 px-3.5 text-sm",
			sm: "h-8 px-2.5 text-xs",
			icon: "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-10 w-full rounded-md border border-border bg-surface px-3 text-sm text-fg placeholder:text-subtle", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40", className),
		...props
	});
}
var DEFAULT_SETTINGS = {
	apiKey: "",
	apiSecret: "",
	paperTrading: true,
	defaultBuyUsdt: 20,
	maxAgeHours: 168,
	minLiquidity: 1e4,
	trailPct: 8,
	tpPct: 25
};
var useScannerStore = create()(persist((set) => ({
	settings: DEFAULT_SETTINGS,
	positions: {},
	seenIds: [],
	updateSettings: (patch) => set((s) => ({ settings: {
		...s.settings,
		...patch
	} })),
	openPosition: (position) => set((s) => ({ positions: {
		...s.positions,
		[position.symbol]: position
	} })),
	closePosition: (symbol) => set((s) => {
		const next = { ...s.positions };
		delete next[symbol];
		return { positions: next };
	}),
	markSeen: (ids) => set((s) => {
		const merged = /* @__PURE__ */ new Set([...s.seenIds, ...ids]);
		return { seenIds: Array.from(merged).slice(-2e3) };
	}),
	applyLivePrices: (prices, trailPct) => set((s) => {
		const next = { ...s.positions };
		let changed = false;
		for (const pos of Object.values(next)) {
			const price = prices[pos.symbol];
			if (!price) continue;
			const peak = Math.max(pos.peakPrice, price);
			const trail = peak * (1 - trailPct / 100);
			if (peak !== pos.peakPrice || trail !== pos.trailingSl) {
				next[pos.symbol] = {
					...pos,
					peakPrice: peak,
					trailingSl: trail
				};
				changed = true;
			}
		}
		return changed ? { positions: next } : s;
	})
}), {
	name: "alpha-scanner",
	skipHydration: true,
	storage: createJSONStorage(() => localStorage)
}));
function SettingsDialog({ onClose }) {
	const settings = useScannerStore((s) => s.settings);
	const updateSettings = useScannerStore((s) => s.updateSettings);
	const [draft, setDraft] = (0, import_react.useState)(settings);
	function save() {
		updateSettings({
			...draft,
			defaultBuyUsdt: Number(draft.defaultBuyUsdt) || 20,
			maxAgeHours: Math.max(0, Number(draft.maxAgeHours) || 0),
			minLiquidity: Math.max(0, Number(draft.minLiquidity) || 0),
			trailPct: Math.max(.1, Number(draft.trailPct) || 8),
			tpPct: Math.max(1, Number(draft.tpPct) || 25)
		});
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-3 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-labelledby": "settings-title",
			className: "w-full max-w-lg rounded-2xl border border-border bg-surface p-5 shadow-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "settings-title",
						className: "text-base font-semibold text-fg",
						children: "Settings"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-9",
						onClick: onClose,
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs font-medium uppercase tracking-wider text-muted",
							children: "Binance API"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-xs leading-relaxed text-subtle",
							children: "Keys stay in this browser only. Use a Spot-only key. Live buys hit Binance market orders on ALPHA_*USDT pairs."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "API key",
								value: draft.apiKey,
								onChange: (e) => setDraft({
									...draft,
									apiKey: e.target.value
								}),
								autoComplete: "off"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								placeholder: "API secret",
								value: draft.apiSecret,
								onChange: (e) => setDraft({
									...draft,
									apiSecret: e.target.value
								}),
								autoComplete: "off"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-3 flex min-h-11 items-center gap-2 text-sm text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: draft.paperTrading,
								onChange: (e) => setDraft({
									...draft,
									paperTrading: e.target.checked
								}),
								className: "size-4 accent-accent"
							}), "Paper trading (simulate fills, no live order)"]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid grid-cols-2 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Default buy (USDT)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 1,
									value: draft.defaultBuyUsdt,
									onChange: (e) => setDraft({
										...draft,
										defaultBuyUsdt: Number(e.target.value)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Max age (hours, 0 = all)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									value: draft.maxAgeHours,
									onChange: (e) => setDraft({
										...draft,
										maxAgeHours: Number(e.target.value)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Min liquidity (USD)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 0,
									value: draft.minLiquidity,
									onChange: (e) => setDraft({
										...draft,
										minLiquidity: Number(e.target.value)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Trailing SL %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: .1,
									step: .1,
									value: draft.trailPct,
									onChange: (e) => setDraft({
										...draft,
										trailPct: Number(e.target.value)
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Take profit %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									min: 1,
									step: 1,
									value: draft.tpPct,
									onChange: (e) => setDraft({
										...draft,
										tpPct: Number(e.target.value)
									})
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						children: "Save"
					})]
				})
			]
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5 text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), children]
	});
}
function Badge({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border border-border bg-surface-2 px-2 py-0.5 text-[11px] font-medium tracking-wide text-muted", className),
		...props
	});
}
var COLUMNS = [
	{
		key: "chain",
		label: "Chain"
	},
	{
		key: "coin",
		label: "Coin"
	},
	{
		key: "age",
		label: "Age"
	},
	{
		key: "size",
		label: "Size"
	},
	{
		key: "entry",
		label: "Entry zone"
	},
	{
		key: "price",
		label: "Current price"
	},
	{
		key: "gain",
		label: "Gain"
	},
	{
		key: "change",
		label: "24h change"
	},
	{
		key: "sl",
		label: "Trailing SL"
	},
	{
		key: "tp",
		label: "TP progress"
	},
	{
		key: "signals",
		label: "Signals"
	},
	{
		key: "trade",
		label: "Trade"
	},
	{
		key: "close",
		label: "Close"
	}
];
function TokenTableHeader() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
		className: "sticky top-0 z-10 bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
			className: "border-b border-border",
			children: COLUMNS.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "whitespace-nowrap px-3 py-3 text-left text-[11px] font-medium uppercase tracking-wider text-muted",
				children: col.label
			}, col.key))
		})
	});
}
function TokenRow({ token, position, now }) {
	const settings = useScannerStore((s) => s.settings);
	const openPosition = useScannerStore((s) => s.openPosition);
	const closePosition = useScannerStore((s) => s.closePosition);
	const [amount, setAmount] = (0, import_react.useState)(String(settings.defaultBuyUsdt));
	const [busy, setBusy] = (0, import_react.useState)(false);
	const gain = position && token.price ? (token.price - position.entryPrice) / position.entryPrice * 100 : null;
	const tpProgress = gain != null ? Math.max(0, Math.min(100, gain / settings.tpPct * 100)) : 0;
	const isNew = now - token.listingTime < 72e5;
	async function buy() {
		const quote = Number(amount);
		if (!Number.isFinite(quote) || quote <= 0) {
			toast.error("Enter a valid USDT size");
			return;
		}
		setBusy(true);
		try {
			let qty = quote / Math.max(token.price, 1e-12);
			let orderId;
			if (!settings.paperTrading) {
				if (!settings.apiKey || !settings.apiSecret) throw new Error("Add Binance API keys in Settings, or keep paper trading on.");
				const result = await placeMarketBuy({ data: {
					apiKey: settings.apiKey,
					apiSecret: settings.apiSecret,
					symbol: token.tradeSymbol,
					quoteOrderQty: quote
				} });
				orderId = result.orderId;
				if (result.executedQty) qty = result.executedQty;
			}
			const entry = token.price;
			openPosition({
				symbol: token.symbol,
				alphaId: token.alphaId,
				tradeSymbol: token.tradeSymbol,
				entryPrice: entry,
				sizeUsdt: quote,
				qty,
				trailingSl: entry * (1 - settings.trailPct / 100),
				peakPrice: entry,
				openedAt: Date.now(),
				paper: settings.paperTrading,
				orderId
			});
			toast.success(settings.paperTrading ? `Paper bought ${token.symbol}` : `Bought ${token.symbol}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Buy failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-b border-border/70 hover:bg-surface-2/60",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: token.chainName })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
				className: "px-3 py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: chartUrl(token),
					target: "_blank",
					rel: "noopener noreferrer",
					className: "inline-flex items-center gap-1.5 font-medium text-fg hover:text-accent",
					children: [token.symbol, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3 opacity-50" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-32 truncate text-[11px] text-subtle",
					children: token.name
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5 font-mono text-xs tabular-nums text-fg",
				children: formatAge(token.listingTime, now)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5 font-mono text-xs tabular-nums text-fg",
				children: position ? formatUsd(position.sizeUsdt) : formatUsd(token.liquidity)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5 font-mono text-xs tabular-nums text-muted",
				children: position ? formatPrice(position.entryPrice) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5 font-mono text-xs tabular-nums text-fg",
				children: formatPrice(token.price)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: cn("px-3 py-2.5 font-mono text-xs tabular-nums", gain == null ? "text-muted" : gain >= 0 ? "text-buy" : "text-sell"),
				children: formatPct(gain)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: cn("px-3 py-2.5 font-mono text-xs tabular-nums", token.percentChange24h >= 0 ? "text-buy" : "text-sell"),
				children: formatPct(token.percentChange24h)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5 font-mono text-xs tabular-nums text-muted",
				children: position ? formatPrice(position.trailingSl) : "—"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 w-20 overflow-hidden rounded-full bg-surface-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-buy transition-[width] duration-300",
						style: { width: `${tpProgress}%` }
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-1",
					children: [
						isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "border-accent/30 bg-accent/10 text-accent",
							children: "NEW"
						}),
						position && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							className: "border-buy/30 bg-buy/10 text-buy",
							children: position.paper ? "PAPER" : "OPEN"
						}),
						token.hotTag && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "HOT" }),
						token.listingCex && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "CEX" })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 1,
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						className: "h-9 w-16 px-2 text-xs",
						"aria-label": `Buy size for ${token.symbol}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "buy",
						size: "sm",
						className: "min-h-9",
						disabled: busy,
						onClick: buy,
						children: busy ? "…" : "Buy"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-3 py-2.5",
				children: position ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					className: "size-9 text-sell",
					"aria-label": `Close ${token.symbol}`,
					onClick: () => closePosition(token.symbol),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-subtle",
					children: "—"
				})
			})
		]
	});
}
function TokenCard({ token, position, now }) {
	const settings = useScannerStore((s) => s.settings);
	const openPosition = useScannerStore((s) => s.openPosition);
	const closePosition = useScannerStore((s) => s.closePosition);
	const [amount, setAmount] = (0, import_react.useState)(String(settings.defaultBuyUsdt));
	const [busy, setBusy] = (0, import_react.useState)(false);
	const gain = position && token.price ? (token.price - position.entryPrice) / position.entryPrice * 100 : null;
	const isNew = now - token.listingTime < 72e5;
	async function buy() {
		const quote = Number(amount);
		if (!Number.isFinite(quote) || quote <= 0) {
			toast.error("Enter a valid USDT size");
			return;
		}
		setBusy(true);
		try {
			let qty = quote / Math.max(token.price, 1e-12);
			let orderId;
			if (!settings.paperTrading) {
				if (!settings.apiKey || !settings.apiSecret) throw new Error("Add Binance API keys in Settings, or keep paper trading on.");
				const result = await placeMarketBuy({ data: {
					apiKey: settings.apiKey,
					apiSecret: settings.apiSecret,
					symbol: token.tradeSymbol,
					quoteOrderQty: quote
				} });
				orderId = result.orderId;
				if (result.executedQty) qty = result.executedQty;
			}
			const entry = token.price;
			openPosition({
				symbol: token.symbol,
				alphaId: token.alphaId,
				tradeSymbol: token.tradeSymbol,
				entryPrice: entry,
				sizeUsdt: quote,
				qty,
				trailingSl: entry * (1 - settings.trailPct / 100),
				peakPrice: entry,
				openedAt: Date.now(),
				paper: settings.paperTrading,
				orderId
			});
			toast.success(settings.paperTrading ? `Paper bought ${token.symbol}` : `Bought ${token.symbol}`);
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Buy failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl border border-border bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: chartUrl(token),
					target: "_blank",
					rel: "noopener noreferrer",
					className: "inline-flex items-center gap-1.5 font-semibold text-fg",
					children: [token.symbol, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3.5 opacity-50" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						token.chainName,
						" · ",
						formatAge(token.listingTime, now)
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm tabular-nums",
						children: formatPrice(token.price)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("font-mono text-xs tabular-nums", token.percentChange24h >= 0 ? "text-buy" : "text-sell"),
						children: formatPct(token.percentChange24h)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-1",
				children: [
					isNew && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						className: "border-accent/30 bg-accent/10 text-accent",
						children: "NEW"
					}),
					position && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						className: "border-buy/30 bg-buy/10 text-buy",
						children: [
							position.paper ? "PAPER" : "OPEN",
							" ",
							formatPct(gain)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: ["Liq ", formatUsd(token.liquidity)] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 1,
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						className: "h-11 flex-1",
						"aria-label": `Buy size for ${token.symbol}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "buy",
						className: "h-11 min-w-20",
						disabled: busy,
						onClick: buy,
						children: busy ? "…" : "Buy"
					}),
					position && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "sell",
						className: "h-11",
						onClick: () => closePosition(token.symbol),
						children: "Close"
					})
				]
			})
		]
	});
}
function Dashboard({ initialTokens }) {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const settings = useScannerStore((s) => s.settings);
	const positions = useScannerStore((s) => s.positions);
	const seenIds = useScannerStore((s) => s.seenIds);
	const markSeen = useScannerStore((s) => s.markSeen);
	const applyLivePrices = useScannerStore((s) => s.applyLivePrices);
	(0, import_react.useEffect)(() => {
		const result = useScannerStore.persist.rehydrate();
		Promise.resolve(result).then(() => setHydrated(true));
	}, []);
	const query = useQuery({
		queryKey: ["alpha-tokens"],
		queryFn: () => fetchAlphaTokens(),
		initialData: initialTokens,
		refetchInterval: 2e3
	});
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(id);
	}, []);
	const tokens = query.data ?? [];
	(0, import_react.useEffect)(() => {
		if (!hydrated || !tokens.length) return;
		const prices = {};
		for (const t of tokens) prices[t.symbol] = t.price;
		applyLivePrices(prices, settings.trailPct);
	}, [
		hydrated,
		tokens,
		applyLivePrices,
		settings.trailPct
	]);
	(0, import_react.useEffect)(() => {
		if (!hydrated || !tokens.length) return;
		const known = new Set(seenIds);
		const fresh = tokens.filter((t) => !known.has(t.alphaId));
		if (seenIds.length && fresh.length) for (const t of fresh.slice(0, 5)) toast.message(`New Alpha listing: ${t.symbol}`, { description: `${t.chainName} · ${t.name}` });
		if (fresh.length) markSeen(fresh.map((t) => t.alphaId));
		else if (!seenIds.length) markSeen(tokens.map((t) => t.alphaId));
	}, [
		hydrated,
		tokens,
		seenIds,
		markSeen
	]);
	const visible = (0, import_react.useMemo)(() => {
		const maxAgeMs = settings.maxAgeHours * 36e5;
		const openSymbols = new Set(Object.keys(positions));
		const passed = tokens.filter((t) => passesScreen(t, now, settings.minLiquidity, maxAgeMs));
		return [...tokens.filter((t) => openSymbols.has(t.symbol) && !passed.some((p) => p.symbol === t.symbol)), ...passed].sort((a, b) => {
			const ao = openSymbols.has(a.symbol) ? 1 : 0;
			const bo = openSymbols.has(b.symbol) ? 1 : 0;
			if (ao !== bo) return bo - ao;
			return b.listingTime - a.listingTime;
		});
	}, [
		tokens,
		positions,
		now,
		settings.maxAgeHours,
		settings.minLiquidity
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-bg/95 px-4 py-3 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid size-8 place-items-center rounded-lg border border-border bg-surface font-mono text-sm text-accent",
							children: "α"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "truncate text-sm font-semibold tracking-tight",
								children: "Alpha Launch Desk"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted",
								children: "New Binance Alpha listings · live safety screen"
							})]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 sm:gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, {
							ok: !query.isError,
							label: query.isError ? "Feed down" : query.isFetching ? "Syncing" : "Live"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden items-center gap-1 text-xs text-muted sm:inline-flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-3.5" }),
								visible.length,
								" shown"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							className: "min-h-10",
							onClick: () => setSettingsOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { className: "size-4" }), "Settings"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 overflow-auto",
				children: query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					title: "Could not reach Binance Alpha",
					body: query.error instanceof Error ? query.error.message : "Retrying…"
				}) : query.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					title: "Loading Alpha feed",
					body: "Pulling the official token list."
				}) : visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
					title: "No open positions yet — waiting for a new token to pass the safety screen.",
					body: `Filter: last ${settings.maxAgeHours || "∞"}h · min liquidity $${settings.minLiquidity.toLocaleString()}. New listings appear here automatically.`
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[1100px] text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenTableHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visible.map((token) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenRow, {
							token,
							position: positions[token.symbol],
							now
						}, token.alphaId)) })]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3 p-3 md:hidden",
					children: visible.map((token) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenCard, {
						token,
						position: positions[token.symbol],
						now
					}, token.alphaId))
				})] })
			}),
			settingsOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDialog, { onClose: () => setSettingsOpen(false) })
		]
	});
}
function passesScreen(token, now, minLiquidity, maxAgeMs) {
	if (token.offline || token.offsell || token.fullyDelisted) return false;
	if (!token.contractAddress) return false;
	if (token.liquidity < minLiquidity) return false;
	if (maxAgeMs > 0 && now - token.listingTime > maxAgeMs) return false;
	return true;
}
function StatusChip({ ok, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5 rounded-full border border-border bg-surface px-2.5 py-1 text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: ok ? "size-3.5 text-buy" : "size-3.5 text-sell" }), label]
	});
}
function Empty({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-lg flex-col items-center px-6 py-24 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-4 grid size-12 place-items-center rounded-2xl border border-border bg-surface font-mono text-lg text-muted",
				children: "α"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs leading-relaxed text-muted",
				children: body
			})
		]
	});
}
function Home() {
	const initialTokens = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, { initialTokens });
}
//#endregion
export { Home as component };
