//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CKI3fxnk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DCLATol3.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DCLATol3.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Biugxaen.js"]
	}
} });
//#endregion
export { tsrStartManifest };
